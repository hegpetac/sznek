import game.*;
import org.junit.Assert;
import org.junit.Test;

public class SnakeTest {

    @Test
    public void testGrow(){
        Snake snake = new Snake();
        int i = snake.getSnake().size();
        snake.grow(new Position(5, 9));
        Assert.assertEquals(i+1, snake.getSnake().size());
    }

    @Test
    public void testMove(){
        Snake snake = new Snake();
        Position pos = new Position(4, 6);
        snake.move(snake.getActual());
        Assert.assertTrue(snake.getSnake().get(0).getX() == pos.getX() && snake.getSnake().get(0).getY() == pos.getY());
    }

    @Test
    public void testCollision(){
        Snake snake = new Snake();
        snake.move(Direction.UP);
        snake.move(Direction.RIGHT);
        snake.move(Direction.DOWN);
        Assert.assertTrue(snake.collision());
    }
}
