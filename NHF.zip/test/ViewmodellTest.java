import game.*;
import org.junit.Assert;
import org.junit.Test;

import javax.swing.text.View;
import java.util.ArrayList;

public class ViewmodellTest {

    @Test
    public void goldenAppleTest(){
        Snake snake = new Snake();
        Viewmodell viewmodell = new Viewmodell("asd");
        GoldenApple goldenApple = new GoldenApple(snake, viewmodell);
        goldenApple.effect();
        Assert.assertEquals(viewmodell.getBasescore(), 200);
        goldenApple.countereffect();
        Assert.assertEquals(viewmodell.getBasescore(), 100);
    }

    @Test
    public void greenAppleTest(){
        Snake snake = new Snake();
        Viewmodell viewmodell = new Viewmodell("asd");
        GreenApple greenApple = new GreenApple(snake, viewmodell);
        greenApple.effect();
        Assert.assertEquals(viewmodell.getTickrate(), 150);
        greenApple.countereffect();
        Assert.assertEquals(viewmodell.getTickrate(), 300);
    }

    @Test
    public void loadTest(){
        Viewmodell viewmodell = new Viewmodell("asd");
        ArrayList<Score> scores = viewmodell.load("scores");
        viewmodell.list(scores);
        for(int i = 0; i < scores.size() - 1; i++){
            Assert.assertTrue(scores.get(4).getHighscore() > scores.get(i).getHighscore());
        }
    }

    @Test
    public void highscoreTest(){
        int verybig = 10000000;
        Viewmodell viewmodell = new Viewmodell("asd");
        ArrayList<Score> scores = viewmodell.load("scores");
        scores.add(new Score("Test", verybig));
        viewmodell.list(scores);
        Assert.assertEquals(verybig, scores.get(4).getHighscore());
    }
}
