import game.*;
import org.junit.Assert;
import org.junit.Test;

public class AppleTest {

    @Test
    public void respawnTest(){
        Snake snake = new Snake();
        Apple apple = new Apple(snake);
        apple.respawn();
        Position pos = apple.getPos();
        for(int i = 0; i < snake.getSnake().size(); i++)
            Assert.assertFalse(pos.getX() == snake.getSnake().get(i).getX() && pos.getY() == snake.getSnake().get(i).getY());
    }

    @Test
    public void eatenTest(){
        Snake snake = new Snake();
        Apple apple = new Apple(snake);
        apple.getPos().setPosition(new Position(4, 6));
        snake.move(snake.getActual());
        Assert.assertTrue(apple.isEaten());
    }
}
