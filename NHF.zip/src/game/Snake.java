package game;

import java.util.*;

public class Snake{
    private ArrayList<Position> snake;
    private Direction actual;

    /**
     * Beállítja a snake kezdeti állapotát, és létrehoz egy 5 hosszúságú snaket.
     */
    public Snake(){
        snake = new ArrayList<>();
        actual = Direction.LEFT;

        Position p1 = new Position(5,6);
        Position p2 = new Position(6,6);
        Position p3 = new Position(7,6);
        Position p4 = new Position(8, 6);
        Position p5 = new Position(9,6);
        snake.add(p1);
        snake.add(p2);
        snake.add(p3);
        snake.add(p4);
        snake.add(p5);

    }

    public ArrayList<Position> getSnake() {
        return snake;
    }


    public Direction getActual() {
        return actual;
    }
    public void setActual(Direction d) {actual = d;}


    /**
     * A snake mozgatásáért felel a kapott irány alapján
     * @param dir kapott irány.
     */
    public void move(Direction dir){
        for(int i = snake.size() - 1; i > 0; i--){
            snake.get(i).setPosition(snake.get(i-1));
        }

        if(dir == Direction.UP)
            snake.get(0).setPosition(snake.get(0).getX(),(((snake.get(0).getY() - 1) % 9) + 9) % 9);
        else if(dir == Direction.RIGHT) {
            snake.get(0).setPosition((snake.get(0).getX() + 1) % 12, snake.get(0).getY());
        }
        else if(dir == Direction.DOWN){
            snake.get(0).setPosition(snake.get(0).getX(), (snake.get(0).getY() + 1) % 9);
        }
        else if(dir == Direction.LEFT){
                snake.get(0).setPosition((((snake.get(0).getX() - 1) % 12) + 12) % 12, snake.get(0).getY());
        }
    }

    /**
     * Megnöveli a snake hosszát eggyel
     * @param plus az új elem helye
     */
    public void grow (Position plus){
        Position pos = new Position(plus.getX(), plus.getY());
        snake.add(pos);
    }

    /**
     * Ellenőrzi, hogy a kígyó belement-e önmagába.
     * @return true ha a kígyó belement önmagába, más esetben false
     */
    public boolean collision(){
        for(int i = 1; i < snake.size(); i++){
            if((snake.get(0).getX() == snake.get(i).getX()) && (snake.get(0).getY() == snake.get(i).getY()))
                return true;
        }
        return false;
    }

    /**
     * Visszaállítja a kígyót az eredeti állopatába.
     */
    public void reset(){
        for(int i = snake.size(); i > 0; i --){
            snake.remove(i-1);
        }
        actual = Direction.LEFT;

        Position p1 = new Position(5,6);
        Position p2 = new Position(6,6);
        Position p3 = new Position(7,6);
        Position p4 = new Position(8, 6);
        Position p5 = new Position(9,6);
        snake.add(p1);
        snake.add(p2);
        snake.add(p3);
        snake.add(p4);
        snake.add(p5);
    }

}
