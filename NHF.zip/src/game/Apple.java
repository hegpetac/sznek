package game;

public class Apple {
    private Position pos;
    private Snake sznek;

    /**
     * Nincs jelentősége, öröklés miatt kell.
     */
    public Apple(){}

    /**
     * Beállítja a példány attribútumait a megfelelő értékre.
     * @param snake kapott snake
     */
    public Apple(Snake snake){
        sznek = snake;
        pos = new Position(3, 2);
    }

    public Position getPos() {
        return pos;
    }

    /**
     * ellenőrzi, hogy az adott pillanatban megették-e az almát
     * @return true, ha az almát megették, false ha nem
     */
    public boolean isEaten(){
        if(sznek.getSnake().get(0).getX() == pos.getX() && sznek.getSnake().get(0).getY() == pos.getY()) {
            return true;
        }
        return false;
    }

    /**
     * Nincs jelentősége, öröklés miatt kell.
     */
    public void effect(){}

    /**
     * Nincs jelentősége, öröklés miatt kell.
     */
    public void countereffect(){}

    /**
     * Ha megették az almát újra elhelyezi.
     */
    public void respawn(){
        boolean adequate = false;
        while(!adequate) {
            pos.setPosition((int)(Math.random()*12), (int)(Math.random()*9));
            for(int i = 0; i < sznek.getSnake().size(); i++) {
                adequate = true;
                if ((sznek.getSnake().get(i).getX() == pos.getX()) && (sznek.getSnake().get(i).getY() == pos.getY())) {
                    adequate = false;
                    break;
                }
            }

        }
    }

    /**
     * Nincs jelentősége, öröklés miatt kell.
     */
    public void spawn(){}

}
