package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Keyboard implements KeyListener {
    private Snake sznek;
    private boolean invert = false;

    /**
     * Beállítja a példány attribútumait a megfelelő értékre.
     * @param snake kapott snake
     */
    public Keyboard(Snake snake){
        sznek = snake;
    }

    /**
     * Nincs jelentősége, öröklés miatt kell.
     * @param e
     */
    public void keyTyped(KeyEvent e){}

    /**
     * A kígyó mozgásirányát változtatja a kapott inputnak megfelelően.
     * @param e
     */
    @Override
    public void keyPressed(KeyEvent e) {
        if(!invert) {
            if (e.getKeyCode() == KeyEvent.VK_W) {
                if (sznek.getActual() != Direction.DOWN)
                    sznek.setActual(Direction.UP);
            } else if (e.getKeyCode() == KeyEvent.VK_S) {
                if (sznek.getActual() != Direction.UP)
                    sznek.setActual(Direction.DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_D) {
                if (sznek.getActual() != Direction.LEFT)
                    sznek.setActual(Direction.RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_A) {
                if (sznek.getActual() != Direction.RIGHT)
                    sznek.setActual(Direction.LEFT);
            }
        }
        else if(invert){
            if (e.getKeyCode() == KeyEvent.VK_S) {
                if (sznek.getActual() != Direction.DOWN)
                    sznek.setActual(Direction.UP);
            } else if (e.getKeyCode() == KeyEvent.VK_W) {
                if (sznek.getActual() != Direction.UP)
                    sznek.setActual(Direction.DOWN);
            } else if (e.getKeyCode() == KeyEvent.VK_A) {
                if (sznek.getActual() != Direction.LEFT)
                    sznek.setActual(Direction.RIGHT);
            } else if (e.getKeyCode() == KeyEvent.VK_D) {
                if (sznek.getActual() != Direction.RIGHT)
                    sznek.setActual(Direction.LEFT);
            }
        }
    }

    public void setInvert(boolean invert) {
        this.invert = invert;
    }

    public boolean isInvert() {
        return invert;
    }

    /**
     * Nincs jelentősége, öröklés miatt kell.
     * @param e
     */
    @Override
    public void keyReleased(KeyEvent e) {}
}
