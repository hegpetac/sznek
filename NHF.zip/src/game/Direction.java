package game;

public enum Direction {
    UP,
    RIGHT,
    DOWN,
    LEFT;
}
