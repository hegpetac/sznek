package game;

import javax.swing.*;
import java.awt.*;

public class Drawer extends JPanel {
    private Snake s;
    private Apple a;
    private GreenApple ga;
    private GoldenApple gold;
    private PoisonedApple poison;
    private Color brown = new Color(101, 67, 33);

    /**
     * Beállítja a példány attribútumait a megfelelő értékre, és beállítja a JPanel attribútumait is.
     * @param snake
     * @param apple
     * @param greenApple
     * @param goldenApple
     * @param poisonedApple
     */
    public Drawer(Snake snake, Apple apple, GreenApple greenApple, GoldenApple goldenApple, PoisonedApple poisonedApple){
        setBackground(Color.BLACK);
        setSize(12*30, 9*30);
        s = snake;
        a = apple;
        ga = greenApple;
        gold = goldenApple;
        poison = poisonedApple;

    }

    /**
     * A játék elemeinek kirajzolásáért felelős függvény.
     * @param g
     */
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        for(int i = 0; i < s.getSnake().size(); i++){
            g.fillRect(s.getSnake().get(i).getX()*30, s.getSnake().get(i).getY()*30,30,30);
        }
        g.setColor(Color.RED);
        g.fillRect(a.getPos().getX()*30, a.getPos().getY()*30,30,30);
        g.setColor(Color.GREEN);
        g.fillRect(ga.getPos().getX()*30, ga.getPos().getY()*30,30,30);
        g.setColor(Color.YELLOW);
        g.fillRect(gold.getPos().getX()*30, gold.getPos().getY()*30,30,30);
        g.setColor(brown);
        g.fillRect(poison.getPos().getX()*30, poison.getPos().getY()*30,30,30);
    }


}
