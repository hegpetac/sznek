package game;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;


public class Viewmodell extends JFrame implements Runnable {
    private static Snake sznek = new Snake();
    private static Keyboard keyboard = new Keyboard(sznek);
    private static Apple apple = new Apple(sznek);
    private static GreenApple greenApple;
    private static GoldenApple goldenApple;
    private static PoisonedApple poisonedApple = new PoisonedApple(sznek, keyboard);
    private static Apple apples[] = {apple, greenApple, goldenApple, poisonedApple};
    private static Drawer main;
    Position last = new Position(0, 0);
    private int tickrate = 300;
    private static int tickcounter;
    private static int lastspecial;
    private static int currentscore = 0;
    private static int basescore = 100;
    private static ArrayList<Score> highscores;
    private static String player;

    /**
     * Létrehozza a JFrame kívánt megjelenítését, beállítja az attribútumait. Beállítja a megfelelő actionListenert.
     * @param player1 a játékos neve
     */
    public Viewmodell(String player1) {
        player = player1;
        setTitle("SNAKE");
        setSize(12 * 30 + 14, 10 * 30 + 8);
        setBackground(Color.GREEN);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        addKeyListener(keyboard);
        greenApple = new GreenApple(sznek, this);
        goldenApple = new GoldenApple(sznek, this);
        apples[0] = apple;
        apples[1] = greenApple;
        apples[2] = goldenApple;
        main = new Drawer(sznek, apple, greenApple, goldenApple, poisonedApple);
        main.setSize(400, 400);
        main.setBackground(Color.BLACK);
        add(main);

    }

    public void setTickrate(int newtickrate) {
        tickrate = newtickrate;
    }

    public void setBasescore(int newbase) {
        basescore = newbase;
    }

    /**
     * A játék lefolyásáért felelős függvény. Létrehozza az objektumokat és kirajzoltatja őket, valamint lépteti a kígyót.
     */
    synchronized public void run() {
        highscores = load("scores");
        //highscores = new ArrayList<>();
        sznek.reset();
      /*  try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        while (!sznek.collision()) {
            tickcounter--;
            if (tickcounter == 20)
                apples[lastspecial].countereffect();
            if (tickcounter == 0)
                apples[(int) (Math.random() * 3) + 1].spawn();
            sznek.move(sznek.getActual());
            for (int i = 0; i < 4; i++) {
                if (apples[i].isEaten()) {
                    sznek.grow(last);
                    apples[i].effect();
                    apples[i].respawn();
                    currentscore += basescore;
                    if (i != 0) {
                        tickcounter = 50;
                        lastspecial = i;
                    }
                }
            }
            main.repaint();
            try {
                wait(tickrate);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            last.setPosition(sznek.getSnake().get(sznek.getSnake().size() - 1));
        }
        MainFrame main = new MainFrame();
        highscores.add(new Score(player, currentscore));
        list(highscores);
        for (int i = 0; i < highscores.size(); i++)
            System.out.println(highscores.get(i).toString());
        save("scores", highscores);
        currentscore = 0;
        apples[lastspecial].countereffect();
        setVisible(false);
    }

    /**
     * Elmenti a legjobb eredményeket.
     * @param file a mentés helye
     * @param scores az eredmények tömbje
     */
    public static void save(String file, ArrayList<Score> scores) {
        try {
            FileOutputStream f = new FileOutputStream(file);
            ObjectOutputStream o = new ObjectOutputStream(f);
            o.writeObject(scores);
            o.close();
        } catch (IOException e) {
        }
    }

    /**
     * betölti fájlból az elmentett legjobb eredményeket.
     * @param file a mentés helye
     * @return az eredmények tömbje
     */
    public static ArrayList<Score> load(String file) {
        try {
            FileInputStream f = new FileInputStream(file);
            ObjectInputStream i = new ObjectInputStream(f);
            ArrayList<Score> scores = new ArrayList<>();
            scores = (ArrayList<Score>) i.readObject();
            return scores;
        } catch (IOException e) {
        } catch (ClassNotFoundException e) {
        }
        return null;
    }

    public ArrayList<Score> getHighscores() {
        return highscores;
    }

    /**
     * Rendezi az eredmények tömbjét, és csak a legjobb 5 eredményt tárolja el.
     * @param scores az eredmények tömbje.
     */
    public void list(ArrayList<Score> scores) {
        Collections.sort(scores, (b1, b2) -> Integer.compare(b1.getHighscore(), b2.getHighscore()));
        if (scores.size() > 5) {
            scores.remove(0);
        }
    }
    public int getBasescore(){
        return basescore;
    }
    public int getTickrate(){
        return tickrate;
    }


    /*public static void main (String[] args){

        game.Viewmodell asd = new game.Viewmodell();
        highscores = load("scores");
        asd.run();
        for (int i = 0; i < highscores.size(); i++)
            System.out.println(highscores.get(i).toString());
        save("scores", highscores);
    }*/
}
