package game;

public class PoisonedApple extends Apple{
    private Position pos;
    private Snake sznek;
    private Keyboard kb;

    /**
     * Beállítja a példány attribútumait a megfelelő értékre.
     * @param snake kapott snake
     * @param keyboard kapott keyboard
     */
    public PoisonedApple(Snake snake, Keyboard keyboard){
        sznek = snake;
        pos = new Position(15, 17);
        kb = keyboard;
    }

    /**
     * átállítja a hozzátartozó keyboard invert attribútumát truera
     */
    public void effect(){
        kb.setInvert(true);
    }

    /**
     * átállítja a hozzátartozó keyboard invert attribútumát falsera
     */
    public void countereffect (){
        kb.setInvert(false);
    }

    /**
     * beállítja az alma pozícióját miután megették
     */
    public void respawn(){
        getPos().setPosition(15, 17);
    }

    public Position getPos() {
        return pos;
    }

    /**
     * ellenőrzi, hogy az adott pillanatban megették-e az almát
     * @return true, ha az almát megették, false ha nem
     */
    public boolean isEaten(){
        if(sznek.getSnake().get(0).getX() == pos.getX() && sznek.getSnake().get(0).getY() == pos.getY()) {
            return true;
        }
        return false;
    }

    /**
     * Elhelyez egy almát a pályán
     */
    public void spawn(){
        boolean adequate = false;
        while(!adequate) {
            pos.setPosition((int)(Math.random()*12), (int)(Math.random()*9));
            for(int i = 0; i < sznek.getSnake().size(); i++) {
                adequate = true;
                if ((sznek.getSnake().get(i).getX() == pos.getX()) && (sznek.getSnake().get(i).getY() == pos.getY())) {
                    adequate = false;
                    break;
                }
            }
        }
    }
}
